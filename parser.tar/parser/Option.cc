#include "Option.h"

#include <stdexcept>

namespace op {
  Option::Option(const std::string& name) {
    // TODO: not yet implemented
  }

  const std::vector<std::string>& Option::getNames() const {
    // TODO: not yet implemented
  }

  const std::string& Option::getValue() const {
    // TODO: not yet implemented
  }

  bool Option::expectValue() const {
    // TODO: not yet implemented
  }

  Option& Option::setDefaultValue(const std::string& value) {
    // TODO: not yet implemented
  }

  Option& Option::hasValue() {
    // TODO: not yet implemented
  }

  Option& Option::addAlias(const std::string& alias) {
    // TODO: not yet implemented
  }

  Option& Option::setMandatory() {
    // TODO: not yet implemented
  }

  bool Option::isMandatory() const {
    // TODO: not yet implemented
  }

  void Option::parsed(){
    // TODO: not yet implemented
  }

  bool Option::operator==(const std::string& arg) const {
    // TODO: not yet implemented
  }

  bool Option::operator!=(const std::string& arg) const {
    // TODO: not yet implemented
  }

  Option& Option::operator=(const std::string& value) {
    // TODO: not yet implemented
  }

  Option::operator bool() const {
    // TODO: not yet implemented
  }
}
