#include "Parser.h"

#include <algorithm>
#include <stdexcept>

namespace op {
  void Parser::parseCommandLine(int argc, const char* const argv[]) {
    // TODO: not yet implemented
  }

  void Parser::printHelp(std::ostream& stream) const {
    // TODO: not yet implemented
  }

  std::size_t Parser::getPositionalArgumentCount() const {
    // TODO: not yet implemented
  }

  Option& Parser::operator()(const std::string& name) {
    // TODO: not yet implemented
  }

  const std::string& Parser::operator[](std::size_t i) const {
    // TODO: not yet implemented
  }
}
